// script.js
const taskList = document.getElementById('task-list');

function addTask(taskText) {
    const li = document.createElement('li');
    li.innerText = taskText;
    taskList.appendChild(li);
}

// Example usage:
addTask('Buy groceries');
addTask('Finish project');
// ... add more tasks as needed
